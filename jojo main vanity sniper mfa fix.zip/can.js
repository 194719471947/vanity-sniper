"use strict";
const undici = require("undici");
const tls = require("tls");
const tlsWebSocket = require("ws");
const fastws = require("tls-websocket");
const extractJsonFromString = require("extract-json-from-string");

// Load config from the separate JSON file
const config = require("./config.json");

let vanity;
const guilds = {};
let start;
let end;

const tlsSocket = tls.connect({ host: config.discordHost, port: 443 });

tlsSocket.on("data", async (data) => {
    const ext = extractJsonFromString(data.toString());
    const find = ext.find((e) => e.code) || ext.find((e) => e.message);
    if (find) {
        end = Date.now();
        const sure = end - start;
        console.log(find);
        const requestBody = JSON.stringify({
            content: `@everyone ${vanity}\n\`\`\`json\n${JSON.stringify(find)}\`\`\``,
        });
        const contentLength = Buffer.byteLength(requestBody);
        const requestHeader = [
            `POST /api/channels/${config.channelId}/messages HTTP/1.1`,
            "Host: discord.com",
            `Authorization: ${config.discordToken}`,
            "Content-Type: application/json",
            `Content-Length: ${contentLength}`,
            `User-Agent: ${config.browser}`,
            `X-Discord-MFA-Authorization: ${config.password}`, // MFA token will be injected here
            "X-Super-Properties: ", // You can provide actual super properties if needed
            "X-Discord-Locale: en-US", // Locale of your choice
            "X-Discord-Timezone: UTC", // Timezone
            "",
            "",
        ].join("\r\n");
        const request = requestHeader + requestBody;
        tlsSocket.write(request);
    }
});

tlsSocket.on("error", (error) => {
    console.log(`tls error`, error);
});

tlsSocket.on("end", () => {
    console.log("tls connection closed");
});

tlsSocket.on("secureConnect", async () => {
    await finishMFA(); 

    const websocket = new tlsWebSocket(config.gatewayUrl);

    websocket.onclose = (event) => {
        console.log(`ws connection closed ${event.reason} ${event.code}`);
    };

    websocket.onmessage = async (message) => {
        const { d, op, t } = JSON.parse(message.data);

        if (t === "GUILD_UPDATE") {
            const find = guilds[d.id];
            if (find) {
                const requestBody = JSON.stringify({ code: find });
                const requestHeader = [
                    `PATCH /api/guilds/${config.guildId}/vanity-url HTTP/1.1`,
                    `Host: ${config.discordHost}`,
                    `Authorization: ${config.discordToken}`,
                    `Content-Type: application/json`,
                    `X-Discord-MFA-Authorization: ${config.password}`,
                    `User-Agent: ${config.browser}`,
                    `X-Super-Properties: `,
                    `X-Discord-Locale: en-US`,
                    `X-Discord-Timezone: UTC`,
                    `Content-Length: ${Buffer.byteLength(requestBody)}`,
                    "",
                    "",
                ].join("\r\n");
                const request = requestHeader + requestBody;
                tlsSocket.write(request);
                vanity = `${find} guild update`;
            }
        } else if (t === "GUILD_DELETE") {
            const find = guilds[d.id];
            if (find) {
                const requestBody = JSON.stringify({ code: find });
                const requestHeader = [
                    `DELETE /api/guilds/${config.guildId}/vanity-url HTTP/1.1`,
                    `Host: ${config.discordHost}`,
                    `Authorization: ${config.discordToken}`,
                    `X-Discord-MFA-Authorization: ${config.password}`,
                    `User-Agent: ${config.browser}`,
                    `X-Super-Properties: `,
                    `X-Discord-Locale: en-US`,
                    `X-Discord-Timezone: UTC`,
                    `Content-Type: application/json`,
                    `Content-Length: ${Buffer.byteLength(requestBody)}`,
                    "",
                ].join("\r\n");
                const request = requestHeader + requestBody;
                tlsSocket.write(request);
                vanity = `${find} guild delete`;
            }
        } else if (t === "READY") {
            d.guilds.forEach((guild) => {
                if (guild.vanity_url_code) {
                    guilds[guild.id] = guild.vanity_url_code;
                }
            });
        }

        if (op === 10) {
            websocket.send(JSON.stringify({
                op: 2,
                d: { token: config.self, intents: 513, properties: { os: config.os, browser: config.browser, device: config.device } },
            }));
            setInterval(() => websocket.send(JSON.stringify({ op: 0, d: {}, s: null, t: "heartbeat" })), d.heartbeat_interval);
        }
    };

    setInterval(() => {
        tlsSocket.write(["GET / HTTP/1.1", `Host: ${config.discordHost}`, "", ""].join("\r\n"));
    }, 400);
});

async function finishMFA() {
    const requestBody = JSON.stringify({
        password: config.password,  // Insert the MFA password directly here
    });
    const requestHeader = [
        `PATCH /mfa/finish HTTP/1.1`,
        `Host: ${config.discordHost}`,
        `Authorization: ${config.discordToken}`,
        `Content-Type: application/json`,
        `X-Discord-MFA-Authorization: ${config.password}`,  // Add the MFA token here
        `User-Agent: ${config.browser}`,
        `X-Super-Properties: `,
        `X-Discord-Locale: en-US`,
        `X-Discord-Timezone: UTC`,
        `Content-Length: ${Buffer.byteLength(requestBody)}`,
        "",
        "",
    ].join("\r\n");
    const request = requestHeader + requestBody;
    tlsSocket.write(request);
}